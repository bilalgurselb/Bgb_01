﻿using System.Net;
using System.Net.Mail;

namespace SiparisApi.Services
{
    public static class EmailService
    {
        public static void SendOrderApprovedEmail(string toEmail, int orderId)
        {
            var smtp = new SmtpClient("smtp.sintankimya.com")
            {
                Port = 587,
                Credentials = new NetworkCredential("bborekci@sintankimya.com", "Y&897313269779uh"),
                EnableSsl = true,
            };

            var mail = new MailMessage("bborekci@sintankimya.com", toEmail)
            {
                Subject = "Sipariş Onaylandı",
                Body = $"Siparişiniz (ID: {orderId}) üretim tarafından onaylandı."
            };

            smtp.Send(mail);
        }
    }
}
