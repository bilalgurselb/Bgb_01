﻿namespace SiparisApi.Dtos
{
    public record SignupDto(string Email, string Password);
}
