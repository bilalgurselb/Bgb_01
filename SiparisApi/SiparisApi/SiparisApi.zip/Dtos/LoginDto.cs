﻿namespace SiparisApi.Dtos
{
    public record LoginDto(string Email, string Password);
}
