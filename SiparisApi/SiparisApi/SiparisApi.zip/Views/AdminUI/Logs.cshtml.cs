using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SiparisApi.Views.AdminUI
{
    public class LogsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
