using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SiparisApi.Views.Account
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
