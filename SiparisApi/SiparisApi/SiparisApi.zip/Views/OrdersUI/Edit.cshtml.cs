using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SiparisApi.Views.OrdersUI
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
