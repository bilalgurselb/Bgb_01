using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SiparisApi.Views.OrderUIList
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
