using System;

namespace SiparisApi.Models
{
    public class Order
    {
        public int Id { get; set; } // Primary Key
        public string Customer { get; set; } // Müşteri adı
        public string Product { get; set; } // Ürün adı
        public int Quantity { get; set; } // Miktar
        public string Unit { get; set; } // pcs, pallets vs.
        public decimal Price { get; set; } // Birim fiyat
        public string Currency { get; set; } // USD, EUR, TL
        public DateTime OrderDate { get; set; } // Sipariş tarihi
        public DateTime? DeliveryDate { get; set; } // Teslim tarihi
        public string PaymentTerm { get; set; } // Ödeme şartı
        public string Transport { get; set; } // Seaway, Truck vs.
        public string DeliveryTerm { get; set; } // Teslim şartı
        public int DueDays { get; set; } // Vade
        public string CreatedBy { get; set; } // Kaydı oluşturan kullanıcı
        public bool IsApprovedByFactory { get; set; } // Fabrika onayı
        public bool IsApprovedBySales { get; set; } // Satış onayı
    }
}
