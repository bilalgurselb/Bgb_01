﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SiparisApi.Data;
using SiparisApi.Models;
using SiparisApi.Services;

namespace SiparisApi.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class OrdersController : ControllerBase
    {
        private readonly AppDbContext _context;

        public OrdersController(AppDbContext context)
        {
            _context = context;
        }
        private void AddLog(string action, string endpoint, string details)
        {
            var email = User.Identity?.Name ?? "Anonymous";

            var log = new Log
            {
                UserEmail = email,
                Action = action,
                Endpoint = endpoint,
                Timestamp = DateTime.Now,
                Details = details
            };

            _context.Logs.Add(log);
            _context.SaveChanges();
        }

        // 📜 Tüm siparişleri listele
        [HttpGet]
        public IActionResult GetOrders()
        {
            var orders = _context.Orders.ToList();
            return Ok(orders);
        }

        // 📦 Yeni sipariş oluştur
        [HttpPost]
        public IActionResult AddOrder([FromBody] Order order)
        {
            if (order == null)
                return BadRequest("Sipariş verisi eksik.");

            order.OrderDate = DateTime.Now;

            _context.Orders.Add(order);
            _context.SaveChanges();
            AddLog("Create", "POST /orders", $"Yeni sipariş eklendi. ID: {order.Id}");
            return Ok(order);
        }

        // 🔍 ID ile sipariş getir
        [HttpGet("{id}")]
        public IActionResult GetOrderById(int id)
        {
            var order = _context.Orders.Find(id);
            if (order == null)
                return NotFound("Sipariş bulunamadı.");
            return Ok(order);
        }
        // 📊 Filtreli sipariş listesi getir
        [HttpGet("filter")]
        public IActionResult GetFilteredOrders(
            [FromQuery] DateTime? startDate,
            [FromQuery] DateTime? endDate,
            [FromQuery] bool? isApprovedByFactory,
            [FromQuery] bool? isApprovedBySales,
            [FromQuery] string? customer)
        {
            var query = _context.Orders.AsQueryable();

            if (startDate.HasValue)
                query = query.Where(o => o.OrderDate >= startDate.Value);

            if (endDate.HasValue)
                query = query.Where(o => o.OrderDate <= endDate.Value);

            if (isApprovedByFactory.HasValue)
                query = query.Where(o => o.IsApprovedByFactory == isApprovedByFactory.Value);

            if (isApprovedBySales.HasValue)
                query = query.Where(o => o.IsApprovedBySales == isApprovedBySales.Value);

            if (!string.IsNullOrWhiteSpace(customer))
                query = query.Where(o => o.Customer.Contains(customer));

            var results = query.OrderByDescending(o => o.OrderDate).ToList();
            return Ok(results);
        }

        // ✏️ Güncelle
        [HttpPut("{id}")]
        public IActionResult UpdateOrder(int id, [FromBody] Order updatedOrder)
        {
            var order = _context.Orders.Find(id);
            if (order == null)
                return NotFound("Sipariş bulunamadı.");
            if (order.IsApprovedByFactory)
                return BadRequest("Bu sipariş üretim tarafından onaylandığı için güncellenemez.");
            order.Customer = updatedOrder.Customer;
            order.Product = updatedOrder.Product;
            order.Quantity = updatedOrder.Quantity;
            order.Unit = updatedOrder.Unit;
            order.Price = updatedOrder.Price;
            order.Currency = updatedOrder.Currency;
            order.OrderDate = updatedOrder.OrderDate;
            order.DeliveryDate = updatedOrder.DeliveryDate;
            order.PaymentTerm = updatedOrder.PaymentTerm;
            order.Transport = updatedOrder.Transport;
            order.DeliveryTerm = updatedOrder.DeliveryTerm;
            order.DueDays = updatedOrder.DueDays;
            order.CreatedBy = updatedOrder.CreatedBy;
            order.IsApprovedByFactory = updatedOrder.IsApprovedByFactory;
            order.IsApprovedBySales = updatedOrder.IsApprovedBySales;

            _context.SaveChanges();
            AddLog("Update", $"PUT /orders/{id}", $"Sipariş güncellendi. ID: {order.Id}");
            return Ok(order);
        }

        // 🗑️ Sil
        [HttpDelete("{id}")]
        public IActionResult DeleteOrder(int id)
        {
            var order = _context.Orders.Find(id);
            if (order == null)
                return NotFound("Sipariş bulunamadı.");

            _context.Orders.Remove(order);
            _context.SaveChanges();
            AddLog("Delete", $"DELETE /orders/{id}", $"Sipariş silindi. ID: {id}");
            return NoContent();
        }
        // 🏭 Üretim tarafından sipariş onayı
        [HttpPut("{id}/approve")]
        [Authorize(Roles = "Factory,Admin")] // sadece yetkililer onaylayabilir
        public IActionResult ApproveOrder(int id)
        {
            var order = _context.Orders.Find(id);
            if (order == null)
                return NotFound("Sipariş bulunamadı.");

            if (order.IsApprovedByFactory)
                return BadRequest("Sipariş zaten üretim tarafından onaylanmış.");

            order.IsApprovedByFactory = true;
            _context.SaveChanges();

            AddLog("Approve", $"PUT /orders/{id}/approve", $"Sipariş üretim tarafından onaylandı. ID: {id}");

            // 📧 E-posta tetikle (mail gönderme kısmını aşağıda detaylı yazacağım)
            EmailService.SendOrderApprovedEmail(order.CreatedBy, order.Id);

            return Ok("Sipariş üretim tarafından onaylandı.");
        }
        [HttpPut("{id}/revoke-approval")]
        [Authorize(Roles = "Admin")]
        public IActionResult RevokeApproval(int id)
        {
            var order = _context.Orders.Find(id);
            if (order == null)
                return NotFound();

            order.IsApprovedByFactory = false;
            _context.SaveChanges();

            AddLog("Revoke", $"PUT /orders/{id}/revoke-approval", $"Sipariş onayı kaldırıldı. ID: {id}");
            return Ok("Sipariş onayı kaldırıldı.");
        }


    }
}
